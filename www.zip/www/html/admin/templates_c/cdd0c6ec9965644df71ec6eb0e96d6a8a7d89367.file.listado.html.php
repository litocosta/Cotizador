<?php /* Smarty version Smarty-3.1.13, created on 2015-02-19 21:49:18
         compiled from ".\templates\listado.html" */ ?>
<?php /*%%SmartyHeaderCode:882551093907147f18-99934049%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cdd0c6ec9965644df71ec6eb0e96d6a8a7d89367' => 
    array (
      0 => '.\\templates\\listado.html',
      1 => 1424378956,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '882551093907147f18-99934049',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_521f35ddd20984_60670460',
  'variables' => 
  array (
    'valor' => 0,
    'valores' => 0,
    'usuarios' => 0,
    'peton' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521f35ddd20984_60670460')) {function content_521f35ddd20984_60670460($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Listado</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body onLoad="mostrarInputFileModificado(1);
        mostrarInputFileModificado(2);">
	<h1>Panel de Control 1.0</h1>
	<br>
	<div id="login">
			Usuario:
			<!--<form id="margen" action="salir.php" method="post">
					<input type="submit" value="Salir"/>
			</form>-->
			<?php  $_smarty_tpl->tpl_vars['valores'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['valores']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['valor']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['valores']->key => $_smarty_tpl->tpl_vars['valores']->value){
$_smarty_tpl->tpl_vars['valores']->_loop = true;
?>
				<?php echo $_smarty_tpl->tpl_vars['valores']->value['usuario'];?>
 /
			<?php }
if (!$_smarty_tpl->tpl_vars['valores']->_loop) {
?>
				<p>No existen usuarios actualmente</p>
			<?php } ?>
			<a id="salir" href="salir.php">Cerrar Sesión</a>
			<br><br>
	</div>
	
	<section id="agregar">
	<h1>Agregar Usuario</h1>
		<form action="agregar.php" method="post" id="margen">
			<label for="nombre">Nombre</label>
			<div>
				<input type="text" name="nombre" class="inputImagen" id="archivo1"><br>
			</div>
			<label for="apellido">Apellido</label>
			<div>
				<input type="text" name="apellido" class="inputImagen" id="archivo1"><br>
			</div>
			<label for="usuario">Usuario</label>
			<div>
				<input type="text" name="usuario" class="inputImagen" id="archivo1"><br>
			</div>
				<br><label for="pass">Pass</label>
			<div>
				<input type="password" name="pass" class="inputImagen" id="archivo1">
			</div>
			<div ><br><br>
				<input type="submit" value="Agregar" class="botonInputFileModificado1"/>
			</div>
		</form>
	</section>
	<section id="contenido">
		<h1>Listado de Usuarios</h1>
		<?php  $_smarty_tpl->tpl_vars['peton'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['peton']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usuarios']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['peton']->key => $_smarty_tpl->tpl_vars['peton']->value){
$_smarty_tpl->tpl_vars['peton']->_loop = true;
?>
			<hr>
			<span><?php echo $_smarty_tpl->tpl_vars['peton']->value['nombre'];?>
<?php echo ' ';?>
<?php echo $_smarty_tpl->tpl_vars['peton']->value['apellido'];?>
</span><a href="editar.php?id=<?php echo $_smarty_tpl->tpl_vars['peton']->value['id'];?>
" title="Editar" class="botonInputFileModificado1">Editar</a>  
			<a href="borrar.php?id=<?php echo $_smarty_tpl->tpl_vars['peton']->value['id'];?>
" onclick="return confirm('Desea borrar este usuario')" title="Borrar" class="botonInputFileModificado1">Borrar</a>
		<?php }
if (!$_smarty_tpl->tpl_vars['peton']->_loop) {
?>
			<p>No existen usuarios actualmente</p>
		<?php } ?>
		<br><br>
	</section>

	
</body>
</html><?php }} ?>