<?php /* Smarty version Smarty-3.1.13, created on 2013-08-29 17:05:39
         compiled from "subirimagen.html" */ ?>
<?php /*%%SmartyHeaderCode:22175521f63433c39e5-63336096%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd295b316fe175907c5ce4b8dd3dc0e7550230c5c' => 
    array (
      0 => 'subirimagen.html',
      1 => 1360666974,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22175521f63433c39e5-63336096',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_521f6343462121_07816594',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521f6343462121_07816594')) {function content_521f6343462121_07816594($_smarty_tpl) {?><!DOCTYPE>
<html lang="es" xmlns="http://www.w3.org/1999/xhtml">
  <head>
      <link rel="shortcut icon" href="images/favicon.ico"/>
      <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
      <meta name="author" content="Antonio Pol"/>
    <link rel="stylesheet" type="text/css" href="../css/estilo.css" media="screen" />
    <title>Subir Imagen</title>
  </head>
    <body>
        <header>
            Video Tutoriales por <span class="ap">Antonio Pol</span>
        </header>
        <section id="contenido">
          <form action="subirimagen.php" enctype="multipart/form-data" method="post">
            Imagen: <input type="file" name="imagen" id="imagen"/><br/>
            <input type="submit" value="Subir Imagen"/>
          </form>
        </section>
  </body>
</html><?php }} ?>