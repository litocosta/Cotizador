<?php /* Smarty version Smarty-3.1.13, created on 2020-09-08 20:42:49
         compiled from "./templates/editar_cad.html" */ ?>
<?php /*%%SmartyHeaderCode:1464906545f5816f95ec3b3-60160120%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a682593db859c87899a60926268a49d326db361' => 
    array (
      0 => './templates/editar_cad.html',
      1 => 1599608455,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1464906545f5816f95ec3b3-60160120',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'cad' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5f5816f95f2db5_87979988',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f5816f95f2db5_87979988')) {function content_5f5816f95f2db5_87979988($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Editar</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Editar CAD: <?php echo $_smarty_tpl->tpl_vars['cad']->value['cad'];?>
</h1>
		<div id="imagen">
			<form id="margen" action="editar_cad.php" method="post">
				<label for="usuario">Usuario</label><br/>
				<input type="hidden" id="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['cad']->value['id'];?>
"/>
				<input type="text" name="cad" class="inputImagen" id="archivo1" value='<?php echo $_smarty_tpl->tpl_vars['cad']->value['cad'];?>
'><br><br><br>
				<input type="submit" value="Editar CAD" class="botonInputFileModificado1"/>
			</form>
			<!--<form action="salir.php" method="post">
				<input type="submit" value="Salir" class="botonInputFileModificado1"/>
			</form>-->
		</div>
</body>
</html><?php }} ?>