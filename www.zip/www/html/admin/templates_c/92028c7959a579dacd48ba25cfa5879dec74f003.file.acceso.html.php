<?php /* Smarty version Smarty-3.1.13, created on 2013-09-04 15:28:50
         compiled from ".\templates\acceso.html" */ ?>
<?php /*%%SmartyHeaderCode:2605250feb823d62be2-91678611%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92028c7959a579dacd48ba25cfa5879dec74f003' => 
    array (
      0 => '.\\templates\\acceso.html',
      1 => 1378301329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2605250feb823d62be2-91678611',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_521e1919a55026_86314198',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521e1919a55026_86314198')) {function content_521e1919a55026_86314198($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Acceso</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Acceso al panel de control</h1>
	<div id="imagen">
		<form id="margen" action="acceder.php" method="post">
			<label for="usuario">Usuario</label><br/>
			<input type="text" class="inputImagen" id="archivo1" name="usuario"><br><br>
			<label for="pass">Pass</label><br/>
			<input type="password" name="pass" class="inputImagen" id="archivo1"><br><br><br>
			<input type="submit" value="Entrar" class="botonInputFileModificado1"/>
		</form>
	</div>
</body>
</html><?php }} ?>