<?php /* Smarty version Smarty-3.1.13, created on 2013-09-04 16:43:46
         compiled from ".\templates\error2.html" */ ?>
<?php /*%%SmartyHeaderCode:17564522747225cb235-53035032%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a03c5f2d941e9ddd396fe2053a68de07e0730d0b' => 
    array (
      0 => '.\\templates\\error2.html',
      1 => 1378305822,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17564522747225cb235-53035032',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_522747225f9dd3_08692614',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_522747225f9dd3_08692614')) {function content_522747225f9dd3_08692614($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Error</title>
</head>
<body>
	<p>No se ha seleccionado ningun archivo</p>
</body>
</html><?php }} ?>