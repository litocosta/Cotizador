<?php /* Smarty version Smarty-3.1.13, created on 2020-09-08 20:42:47
         compiled from "./templates/editar_dolar.html" */ ?>
<?php /*%%SmartyHeaderCode:15259907535f5816f7a92e02-26445187%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eafdb0de440c884e55b0239d55c48f7cc3eccb0a' => 
    array (
      0 => './templates/editar_dolar.html',
      1 => 1599608455,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15259907535f5816f7a92e02-26445187',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'dolar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5f5816f7a99b31_62534867',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f5816f7a99b31_62534867')) {function content_5f5816f7a99b31_62534867($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Editar</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Editar CAD: <?php echo $_smarty_tpl->tpl_vars['dolar']->value['dolar'];?>
</h1>
		<div id="imagen">
			<form id="margen" action="editar_dolar.php" method="post">
				<label for="usuario">Usuario</label><br/>
				<input type="hidden" id="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['dolar']->value['id'];?>
"/>
				<input type="text" name="dolar" class="inputImagen" id="archivo1" value='<?php echo $_smarty_tpl->tpl_vars['dolar']->value['dolar'];?>
'><br><br><br>
				<input type="submit" value="Editar dólar" class="botonInputFileModificado1"/>
			</form>
			<!--<form action="salir.php" method="post">
				<input type="submit" value="Salir" class="botonInputFileModificado1"/>
			</form>-->
		</div>
</body>
</html><?php }} ?>