<?php /* Smarty version Smarty-3.1.13, created on 2020-11-27 20:22:32
         compiled from "./templates/acceso.html" */ ?>
<?php /*%%SmartyHeaderCode:940790551552917d2715f18-54416230%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '87e5869118995067829fad537129be730e271420' => 
    array (
      0 => './templates/acceso.html',
      1 => 1605703110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '940790551552917d2715f18-54416230',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_552917d27690d2_75799874',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_552917d27690d2_75799874')) {function content_552917d27690d2_75799874($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Acceso</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Acceso al panel de control</h1>
	<div id="imagen">
		<form id="margen" action="acceder.php" method="post">
			<label for="usuario">Usuario</label><br/>
			<input type="text" class="inputImagen" id="archivo1" name="usuario"><br><br>
			<label for="pass">Pass</label><br/>
			<input type="password" name="pass" class="inputImagen" id="archivo1"><br><br><br>
			<input type="submit" value="Entrar" class="botonInputFileModificado1"/>
		</form>
	</div>
</body>
</html><?php }} ?>