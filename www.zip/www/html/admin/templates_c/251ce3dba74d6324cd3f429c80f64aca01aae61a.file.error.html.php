<?php /* Smarty version Smarty-3.1.13, created on 2013-08-29 13:28:01
         compiled from ".\templates\error.html" */ ?>
<?php /*%%SmartyHeaderCode:1553350feb9a7493068-72736252%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '251ce3dba74d6324cd3f429c80f64aca01aae61a' => 
    array (
      0 => '.\\templates\\error.html',
      1 => 1360666974,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1553350feb9a7493068-72736252',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_521f30411d15c4_44824323',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521f30411d15c4_44824323')) {function content_521f30411d15c4_44824323($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Error</title>
</head>
<body>
	<p>Se ha producido un error o no tienes suficientes privilegios para realizar esta acción.</p>
</body>
</html><?php }} ?>