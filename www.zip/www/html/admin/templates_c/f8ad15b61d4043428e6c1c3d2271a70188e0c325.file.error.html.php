<?php /* Smarty version Smarty-3.1.13, created on 2020-12-01 12:40:13
         compiled from "./templates/error.html" */ ?>
<?php /*%%SmartyHeaderCode:938519190552917d6a6e445-83684059%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f8ad15b61d4043428e6c1c3d2271a70188e0c325' => 
    array (
      0 => './templates/error.html',
      1 => 1605703110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '938519190552917d6a6e445-83684059',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_552917d6a74c13_13041282',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_552917d6a74c13_13041282')) {function content_552917d6a74c13_13041282($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Error</title>
</head>
<body>
	<p>Se ha producido un error o no tienes suficientes privilegios para realizar esta acción.</p>
</body>
</html><?php }} ?>