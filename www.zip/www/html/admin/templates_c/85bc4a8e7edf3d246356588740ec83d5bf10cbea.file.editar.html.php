<?php /* Smarty version Smarty-3.1.13, created on 2013-09-04 15:40:13
         compiled from ".\templates\editar.html" */ ?>
<?php /*%%SmartyHeaderCode:152945109395f1546e9-14964873%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '85bc4a8e7edf3d246356588740ec83d5bf10cbea' => 
    array (
      0 => '.\\templates\\editar.html',
      1 => 1378302009,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '152945109395f1546e9-14964873',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_521f4614c7ffd8_13694806',
  'variables' => 
  array (
    'usuario' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_521f4614c7ffd8_13694806')) {function content_521f4614c7ffd8_13694806($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Editar</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Editar Usuario: <?php echo $_smarty_tpl->tpl_vars['usuario']->value['usuario'];?>
</h1>
		<div id="imagen">
			<form id="margen" action="editar.php" method="post">
				<label for="usuario">Usuario</label><br/>
				<input type="hidden" id="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['id'];?>
"/>
				<input type="text" name="usuario" class="inputImagen" id="archivo1" value='<?php echo $_smarty_tpl->tpl_vars['usuario']->value['usuario'];?>
' readonly><br><br><br>
				<label for="pass">Pass</label><br>
				<input type="hidden" name="passantigua" id="passantigua" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['pass'];?>
"/>
				<input type="password" name="pass" class="inputImagen" id="archivo1"><br><br><br>
				<input type="submit" value="Editar Usuario" class="botonInputFileModificado1"/>
			</form>
			<!--<form action="salir.php" method="post">
				<input type="submit" value="Salir" class="botonInputFileModificado1"/>
			</form>-->
		</div>
</body>
</html><?php }} ?>