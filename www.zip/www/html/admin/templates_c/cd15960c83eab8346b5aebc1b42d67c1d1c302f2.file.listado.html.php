<?php /* Smarty version Smarty-3.1.13, created on 2020-12-09 13:02:38
         compiled from "./templates/listado.html" */ ?>
<?php /*%%SmartyHeaderCode:1369740894552919532877d8-05373645%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cd15960c83eab8346b5aebc1b42d67c1d1c302f2' => 
    array (
      0 => './templates/listado.html',
      1 => 1605703110,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1369740894552919532877d8-05373645',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_552919532e6882_17126875',
  'variables' => 
  array (
    'valor' => 0,
    'valores' => 0,
    'usuarios' => 0,
    'peton' => 0,
    'parametros' => 0,
    'para' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_552919532e6882_17126875')) {function content_552919532e6882_17126875($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Listado</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body onLoad="mostrarInputFileModificado(1);
        mostrarInputFileModificado(2);">
	<h1>Panel de Control 1.0</h1>
	<br>
	<div id="login">
			Usuario:
			<!--<form id="margen" action="salir.php" method="post">
					<input type="submit" value="Salir"/>
			</form>-->
			<?php  $_smarty_tpl->tpl_vars['valores'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['valores']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['valor']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['valores']->key => $_smarty_tpl->tpl_vars['valores']->value){
$_smarty_tpl->tpl_vars['valores']->_loop = true;
?>
				<?php echo $_smarty_tpl->tpl_vars['valores']->value['usuario'];?>
 /
			<?php }
if (!$_smarty_tpl->tpl_vars['valores']->_loop) {
?>
				<p>No existen usuarios actualmente</p>
			<?php } ?>
			<a id="salir" href="salir.php">Cerrar Sesión</a>
			<br><br>
	</div>
	
	<section id="agregar">
	<h1>Agregar Usuario</h1>
		<form action="agregar.php" method="post" id="margen">
			<label for="nombre">Nombre</label>
			<div>
				<input type="text" name="nombre" class="inputImagen" id="archivo1"><br>
			</div>
			<label for="apellido">Apellido</label>
			<div>
				<input type="text" name="apellido" class="inputImagen" id="archivo1"><br>
			</div>
			<label for="usuario">Usuario</label>
			<div>
				<input type="text" name="usuario" class="inputImagen" id="archivo1"><br>
			</div>
			<label for="usuario">Tipo de acceso</label>
			<div>
				<select type="text" name="acceso" class="inputImagen" id="archivo1"><br>
					<option value="a">Administrador</option>
					<option value="b">Cotizador</option>
					<option value="c">Usados</option>
					
				</select>
			</div>
			<label for="usuario">Código personal</label>
			<div>
				<input type="text" name="cod" class="inputImagen" id="archivo1"><br>
			</div>
			<br><label for="pass">Pass</label>
			<div>
				<input type="password" name="pass" class="inputImagen" id="archivo1">
			</div>
			<div ><br><br>
				<input type="submit" value="Agregar" class="botonInputFileModificado1"/>
			</div>
		</form>
	</section>
	<section id="contenido">
		<h1>Listado de Usuarios</h1>
		<?php  $_smarty_tpl->tpl_vars['peton'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['peton']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['usuarios']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['peton']->key => $_smarty_tpl->tpl_vars['peton']->value){
$_smarty_tpl->tpl_vars['peton']->_loop = true;
?>
			<hr>
			<span><?php echo $_smarty_tpl->tpl_vars['peton']->value['nombre'];?>
<?php echo ' ';?>
<?php echo $_smarty_tpl->tpl_vars['peton']->value['apellido'];?>
</span><a href="editar.php?id=<?php echo $_smarty_tpl->tpl_vars['peton']->value['id'];?>
" title="Editar" class="botonInputFileModificado1">Editar</a>  
			<a href="borrar.php?id=<?php echo $_smarty_tpl->tpl_vars['peton']->value['id'];?>
" onclick="return confirm('Desea borrar este usuario')" title="Borrar" class="botonInputFileModificado1">Borrar</a>
		<?php }
if (!$_smarty_tpl->tpl_vars['peton']->_loop) {
?>
			<p>No existen usuarios actualmente</p>
		<?php } ?>
		<br><br>
	</section>
	<section id="parametro">
		<h1>Parámetros</h1>
		<?php  $_smarty_tpl->tpl_vars['para'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['para']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['parametros']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['para']->key => $_smarty_tpl->tpl_vars['para']->value){
$_smarty_tpl->tpl_vars['para']->_loop = true;
?>
		Dolar<span><?php echo $_smarty_tpl->tpl_vars['para']->value['dolar'];?>
</span><a href="editar_dolar.php?id=<?php echo $_smarty_tpl->tpl_vars['para']->value['id'];?>
" title="Editar" class="botonInputFileModificado1">Editar</a><br>  	
		<hr>CAD<span><?php echo $_smarty_tpl->tpl_vars['para']->value['cad'];?>
</span><a href="editar_cad.php?id=<?php echo $_smarty_tpl->tpl_vars['para']->value['id'];?>
" title="Editar" class="botonInputFileModificado1">Editar</a><br>  	<br>  	
		<?php } ?>
		</section>

	
</body>
</html><?php }} ?>