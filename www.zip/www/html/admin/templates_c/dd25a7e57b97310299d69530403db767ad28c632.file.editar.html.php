<?php /* Smarty version Smarty-3.1.13, created on 2021-01-25 21:52:07
         compiled from "./templates/editar.html" */ ?>
<?php /*%%SmartyHeaderCode:749846445553a9fc85a76e1-11001285%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dd25a7e57b97310299d69530403db767ad28c632' => 
    array (
      0 => './templates/editar.html',
      1 => 1611622323,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '749846445553a9fc85a76e1-11001285',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_553a9fc861ab73_56300592',
  'variables' => 
  array (
    'usuario' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_553a9fc861ab73_56300592')) {function content_553a9fc861ab73_56300592($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Editar</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<h1>Editar Usuario: <?php echo $_smarty_tpl->tpl_vars['usuario']->value['usuario'];?>
</h1>
		<div id="imagen">
			<form id="margen" action="editar.php" method="post">
				<label for="usuario">Usuario</label><br>
				<input type="hidden" id="id" name="id" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['id'];?>
"/>
				<input type="text" name="usuario" class="inputImagen" id="archivo1" value='<?php echo $_smarty_tpl->tpl_vars['usuario']->value['usuario'];?>
' readonly>No se puede cambiar<br><br>
				<label for="nombre">Nombre</label><br>
				<input type="text" name="nombre" class="inputImagen" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['nombre'];?>
"><br><br>
				<label for="apellido">Apellido</label><br>
				<input type="text" name="apellido" class="inputImagen" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['apellido'];?>
"><br><br>
				<label for="usuario">Tipo de acceso actual: </label>
				<?php if ($_smarty_tpl->tpl_vars['usuario']->value['tipo']=="a"){?>
				Administrador
				<?php }elseif($_smarty_tpl->tpl_vars['usuario']->value['tipo']=="b"){?>
				Cotizador
				<?php }else{ ?>
				Usados
				<?php }?>
				<div>
					
					<select type="text" name="acceso" class="inputImagen" id="archivo1"><br>
						<option value="a">Administrador</option>
						<option value="b">Cotizador</option>
						<option value="c">Usados</option>
				
					</select>
				</div><br><br>
				<label for="usuario">Visualización de Precios actual:</label>
				<?php if ($_smarty_tpl->tpl_vars['usuario']->value['ver']=="s"){?>
				Si
				<?php }else{ ?>
				No
				<?php }?>
				<div>
					
					<select type="text" name="precio" class="inputImagen"  id="archivo1"><br>
						<option value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['ver'];?>
"></option>
						<option value="s">Si</option>
						<option value="n">No</option>
				
				
					</select>
				</div><br><br>
				<label for="pass">Pass</label><br>
				<input type="hidden" name="passantigua" id="passantigua" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['pass'];?>
"/>
				<input type="password" name="pass" class="inputImagen" id="archivo1"><br><br><br>
				<label for="pass">Codigo personal</label><br>
				<input type="text" name="codant" id="passantigua" class="inputImagen" value="<?php echo $_smarty_tpl->tpl_vars['usuario']->value['cod'];?>
" />
				<br><br>
				<input type="submit" value="Guardar" class="botonInputFileModificado1"/>
				<a class="botonInputFileModificado1" href="index.php">Cancelar</a>
			</form>

			<!--<form action="salir.php" method="post">
				<input type="submit" value="Salir" class="botonInputFileModificado1"/>
			</form>-->
		</div>
</body>
</html><?php }} ?>