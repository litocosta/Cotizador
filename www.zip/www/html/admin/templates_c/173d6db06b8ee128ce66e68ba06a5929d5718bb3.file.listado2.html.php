<?php /* Smarty version Smarty-3.1.13, created on 2013-10-25 06:20:52
         compiled from ".\templates\listado2.html" */ ?>
<?php /*%%SmartyHeaderCode:120835220a30e7e3715-86388527%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '173d6db06b8ee128ce66e68ba06a5929d5718bb3' => 
    array (
      0 => '.\\templates\\listado2.html',
      1 => 1378305273,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '120835220a30e7e3715-86388527',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5220a30e89a950_47980024',
  'variables' => 
  array (
    'valor' => 0,
    'valores' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5220a30e89a950_47980024')) {function content_5220a30e89a950_47980024($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8"/>
	<title>Listado</title>
	<script type="text/javascript" src="js/modificarEstiloInputFile.js"></script>
    <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body onLoad="mostrarInputFileModificado(1);
        mostrarInputFileModificado(2);">
    <h1>Panel de Control 1.0</h1>
	<br>
    <div id="login">
			Usuario:
			<!--<form id="margen" action="salir.php" method="post">
					<input type="submit" value="Salir"/>
			</form>-->
			<?php  $_smarty_tpl->tpl_vars['valores'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['valores']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['valor']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['valores']->key => $_smarty_tpl->tpl_vars['valores']->value){
$_smarty_tpl->tpl_vars['valores']->_loop = true;
?>
				<?php echo $_smarty_tpl->tpl_vars['valores']->value['usuario'];?>
 /
			<?php }
if (!$_smarty_tpl->tpl_vars['valores']->_loop) {
?>
				<p>No existen usuarios actualmente</p>
			<?php } ?>
			<a id="salir" href="salir.php">Cerrar Sesión</a>
			<br><br>
	</div>
	<section id="cuerpo">
		<h1>Subir Imagen</h1>
		<section id="contenido">
	       <form id="margen" name="form1" method="post" action="recibir.php" enctype="multipart/form-data" id="margen">
			Seleccione la Imagen:
				 <div>
		            <input class="inputImagen" id="archivo1"/>
		            <div class="botonInputFileModificado">
		                <input type="file" class="inputImagenOculto" id="archivo_oculto1" name="imagen"/>
		                <div class="boton">Examinar</div>    
		            </div>        
		        </div>
			<br>
			Descripción:
			    <div>
		            <input type="text" name="descripcion" class="inputImagen" id="archivo1"/>
		        </div>
		        <br><br><br>
				<input type="submit" name="Agregar" id="Aceptar" value="Agregar" class="botonInputFileModificado1" />
			
		</form>
		<br>
	    </section>
	    
	</section>
</body>
</html><?php }} ?>