<?php
session_start();
$usuario = $_SESSION["admin"];
//echo "UasiaRIO: ".$usuario;
define('DB_SERVER', 'localhost');
define('DB_SERVER_USERNAME', 'root');
define('DB_SERVER_PASSWORD', 'gera1606');
define('DB_DATABASE', 'montironi');

$connexion = new mysqli(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE);

$html = '';
$key = $_POST['key'];
$provi = $_POST['provi'];;
$result = $connexion->query(
    //'SELECT * FROM cotizados WHERE patente LIKE "%'.strip_tags($key).'%"');//original
    'SELECT * FROM municipios WHERE provincia='.$provi.' AND localidad LIKE "%'.strip_tags($key).'%"');
    //    'SELECT * FROM cotizados WHERE usuario="'.$usuario.'" AND patente LIKE "%'.strip_tags($key).'%"');
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {                
        $html .= '<div><a class="suggest-element" data="'.utf8_encode($row['localidad']).' '.'" id="product'.$row['id'].'">'
       .utf8_encode($row['localidad']).'</a></div>';
       //$html .= '<div><a class="suggest-element" data="'.'" id="product'.$row['id'].'">'
      // .utf8_encode($row['localidad']).'</a></div>';
    }
}
echo $html;
?>