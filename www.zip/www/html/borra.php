<?php
 
      //$usuario = $_SESSION["admin"];
      $servername = "localhost";
      $database = "montironi";
      $username = "root";
      $password = "gera1606";
      $conn = mysqli_connect($servername, $username, $password, $database);
      $sql = "SELECT * FROM acara";
      $resultado = mysqli_query($conn, $sql) or die ('Error en el query database');
      while($fila = mysqli_fetch_array( $resultado ) )
        {
            $up = "DELETE FROM acara WHERE id>=55874";
            $resultado2 = mysqli_query($conn, $up);
        }
      //$row = mysqli_fetch_array($resultado);
      //$nombre_usuario = $row["nombre"].' '.$row['apellido'];


?>
