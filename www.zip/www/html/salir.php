<?php
//include('contra.php');
session_start();
$sesion=$_SESSION["admin"];
/*echo $sesion;*/
$db = new mysqli("localhost", "root", "gera1606", "montironi");
$query="select id, usuario, control from usuarios";
$control=array();
$resultado=$db->query($query);
$valor=$resultado->fetch_array();

$resultado="Update usuarios set control='' where control='$sesion'";
$db->query($resultado);
session_destroy();
clearstatcache();
header("location: index.php");
?>