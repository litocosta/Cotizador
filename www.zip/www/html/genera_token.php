<?php
require_once 'HTTP/Request2.php';
$request = new HTTP_Request2();
$request->setUrl('https://demo.api.infoauto.com.ar/cars/auth/login');
$request->setMethod(HTTP_Request2::METHOD_POST);
$request->setConfig(array(
  'follow_redirects' => TRUE
));
$request->setHeader(array(
  'Authorization' => 'Basic bW1vbnRpcm9uaUBtb250aXJvbmkuY29tOkFQSTIwMjBtbW9udGlyb24=',
  'Cookie' => 'session=.eJyrVspMSc0rySyp1EssLcmIL6ksSFWyyivNydFByGSmQIRqAZu4EWc.Xxdw2Q.djRGqAAAzNRF7X4VNdR8MoCqxII'
));
try {
  $response = $request->send();
  if ($response->getStatus() == 200) {
    //echo $response->getBody();
    $choto = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1OTUzNzMyNDYsIm5iZiI6MTU5NTM3MzI0NiwianRpIjoiYmFhYzQ2NjItN2U4OC00NTIwLWJmMTQtMzJjODkwZThjZTQ5IiwiZXhwIjoxNTk1Mzc2ODQ2LCJpZGVudGl0eSI6MzUsImZyZXNoIjpmYWxzZSwidHlwZSI6ImFjY2VzcyIsInVzZXJfY2xhaW1zIjp7InJvbGVzIjpbeyJpZCI6MTEsIm5hbWUiOiIwa20ifSx7ImlkIjoxMCwibmFtZSI6IkV4dHJhcyJ9LHsiaWQiOjE0LCJuYW1lIjoiSGlzdFx1MDBmM3JpY28ifSx7ImlkIjo5LCJuYW1lIjoiTW9kZWxvcyJ9LHsiaWQiOjEyLCJuYW1lIjoiVXNhZG9zIn1dfX0.AoZXgIK_Imt-Wl-cGNTJdMCF794R5mlYNQ3dDkhz_cI';
    //echo strlen($choto);
    $todo = $response->getBody();
    $refre = "refresh_token";
    //echo strpos($todo, $refre);
    //echo '<BR>'.strpos($todo,'"}');
    //echo '<BR>'.strpos($todo,'"}');
    //$token = substr($todo,17,484);
    $token = substr($todo,17,472);
    //echo '<BR>HOLAAAAA  '.$token;
  }
  else {
    echo 'Unexpected HTTP status: ' . $response->getStatus() . ' ' .
    $response->getReasonPhrase();
  }
}
catch(HTTP_Request2_Exception $e) {
  echo 'Error: ' . $e->getMessage();
}
?>